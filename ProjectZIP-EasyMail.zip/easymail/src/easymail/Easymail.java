
package easymail;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class Easymail extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Easy Mail - Making Mailing Easy");
        
        
        Image ico = new Image("easymail/ico.png");
        stage.getIcons().add(ico);
        stage.setScene(scene);
        //stage.setResizable(false);
        //stage.initStyle(StageStyle.UTILITY);
        stage.show();
        
    }

    
    public static void main(String[] args) {
        launch(args);
    }
    
}
