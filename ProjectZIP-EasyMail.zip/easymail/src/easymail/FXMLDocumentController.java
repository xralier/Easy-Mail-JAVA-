
package easymail;


import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;

import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.stage.Stage;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;




public class FXMLDocumentController implements Initializable {
    int j = 0 ;
    
  
     
    
     @FXML
    ImageView backimg;

    @FXML
    ImageView logoimg;

    @FXML
     ImageView dragndrop;

    @FXML
     TextArea added;

    @FXML
     TextField user;

    @FXML
    PasswordField pass;

    @FXML
     TextField tomail;

    @FXML
    TextField sub;

    @FXML
     TextArea msg;
    
    @FXML
     Button send;
    
    @FXML
     Button abt;
    
    @FXML
    Button htu;

    
    
    String UserMail ;
    String Password ;
    String To ;
   String Subject;
   String Message ;
   
  
   String path[] = new String [20];  

    @FXML
    public void handleDragOver(DragEvent event) {
        
      Dragboard board = event.getDragboard();
      List <File> att = board.getFiles();
      path[j] = att.get(0).toPath().toString();
      event.acceptTransferModes(TransferMode.ANY);
      
    }
 
     
    
    Integer i = 0;
    Integer m = 0;
  
 @FXML
    public void handleDrop(DragEvent event) {
    System.out.println(path[m]);
    i = i+1;
    String S = i.toString() +" file added";
    added.setText(S);   
    m++;    
    j++;    
    } 
 
 
    
    
    
      
    
    
    
    @FXML
    public void handleSend(javafx.event.ActionEvent event) throws EmailException, IOException {
     
    // input 
      
     UserMail = user.getText();
      Password = pass.getText();
      To = tomail.getText();
      Subject = sub.getText();
      Message = msg.getText();
     
     // Attachment 
    EmailAttachment attachment1 = new EmailAttachment();
    attachment1.setPath(path[0]);
    attachment1.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment2 = new EmailAttachment();
    attachment2.setPath(path[1]);
    attachment2.setDisposition(EmailAttachment.ATTACHMENT);
      
    EmailAttachment attachment3 = new EmailAttachment();
    attachment3.setPath(path[2]);
    attachment3.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment4 = new EmailAttachment();
    attachment4.setPath(path[3]);
    attachment4.setDisposition(EmailAttachment.ATTACHMENT);
     
    EmailAttachment attachment5 = new EmailAttachment();
    attachment5.setPath(path[4]);
    attachment5.setDisposition(EmailAttachment.ATTACHMENT);
    

    EmailAttachment attachment6 = new EmailAttachment();
    attachment6.setPath(path[5]);
    attachment6.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment7 = new EmailAttachment();
    attachment7.setPath(path[6]);
    attachment7.setDisposition(EmailAttachment.ATTACHMENT);
      
    EmailAttachment attachment8 = new EmailAttachment();
    attachment8.setPath(path[7]);
    attachment8.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment9 = new EmailAttachment();
    attachment9.setPath(path[8]);
    attachment9.setDisposition(EmailAttachment.ATTACHMENT);
     
    EmailAttachment attachment10 = new EmailAttachment();
    attachment10.setPath(path[9]);
    attachment10.setDisposition(EmailAttachment.ATTACHMENT);

    
    EmailAttachment attachment11 = new EmailAttachment();
    attachment11.setPath(path[10]);
    attachment11.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment12 = new EmailAttachment();
    attachment12.setPath(path[11]);
    attachment12.setDisposition(EmailAttachment.ATTACHMENT);
      
    EmailAttachment attachment13 = new EmailAttachment();
    attachment13.setPath(path[12]);
    attachment13.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment14 = new EmailAttachment();
    attachment14.setPath(path[13]);
    attachment14.setDisposition(EmailAttachment.ATTACHMENT);
     
    EmailAttachment attachment15 = new EmailAttachment();
    attachment15.setPath(path[14]);
    attachment15.setDisposition(EmailAttachment.ATTACHMENT);
    

    EmailAttachment attachment16 = new EmailAttachment();
    attachment16.setPath(path[15]);
    attachment16.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment17 = new EmailAttachment();
    attachment17.setPath(path[16]);
    attachment17.setDisposition(EmailAttachment.ATTACHMENT);
      
    EmailAttachment attachment18 = new EmailAttachment();
    attachment18.setPath(path[17]);
    attachment18.setDisposition(EmailAttachment.ATTACHMENT);
    
    EmailAttachment attachment19 = new EmailAttachment();
    attachment19.setPath(path[18]);
    attachment19.setDisposition(EmailAttachment.ATTACHMENT);
     
    EmailAttachment attachment20 = new EmailAttachment();
    attachment20.setPath(path[19]);
    attachment20.setDisposition(EmailAttachment.ATTACHMENT);
    

// mail    
     MultiPartEmail email = new MultiPartEmail();
     email.setHostName("smtp.googlemail.com");
     email.setSmtpPort(465);
     email.setAuthenticator(new DefaultAuthenticator(UserMail, Password));
     email.setSSLOnConnect(true);
     email.setFrom(UserMail);
     email.setSubject(Subject);
     email.setMsg(Message);
     email.addTo(To);
     
   // attachment   
   
   if (i == 1) 
   {
   email.attach(attachment1);
   }
   
   if (i == 2)
   {
   email.attach(attachment1);
   email.attach(attachment2);
 
   }
   
   if (i == 3) 
   {
    email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);

   }
   
   if (i == 4)
   {
    email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);

   }
   
    if (i == 5) 
   {
    email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
 
   }
   
   if (i == 6)
   {
    email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    
   }
    
   if (i == 7) 
   {
    email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
   
   }
   
   if (i == 8)
   {
    email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    
   }
    
   if (i == 9) 
   {
    email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
   
   }
   
   if (i == 10)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);

   }
   
   if (i == 11)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    
   }
   
   if (i == 12)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);

   }
   
   if (i == 13)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);

   }
   
   if (i == 14)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);
    email.attach(attachment14);
    
   }
   
   if (i == 15)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);
    email.attach(attachment14);
    email.attach(attachment15);
  
   }
   
   if (i == 16)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);
    email.attach(attachment14);
    email.attach(attachment15);
    email.attach(attachment16);
    
   }
   
   if (i == 17)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);
    email.attach(attachment14);
    email.attach(attachment15);
    email.attach(attachment16);
    email.attach(attachment17);
    
   }
   
   if (i == 18)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);
    email.attach(attachment14);
    email.attach(attachment15);
    email.attach(attachment16);
    email.attach(attachment17);
    email.attach(attachment18);
   
   }
   
   if (i == 19)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);
    email.attach(attachment14);
    email.attach(attachment15);
    email.attach(attachment16);
    email.attach(attachment17);
    email.attach(attachment18);
    email.attach(attachment19);
    
   }
   
   if (i == 20)
   {email.attach(attachment1);
    email.attach(attachment2);
    email.attach(attachment3);
    email.attach(attachment4);
    email.attach(attachment5);
    email.attach(attachment6);
    email.attach(attachment7);
    email.attach(attachment8);
    email.attach(attachment9);
    email.attach(attachment10);
    email.attach(attachment11);
    email.attach(attachment12);
    email.attach(attachment13);
    email.attach(attachment14);
    email.attach(attachment15);
    email.attach(attachment16);
    email.attach(attachment17);
    email.attach(attachment18);
    email.attach(attachment19);
    email.attach(attachment20);
   }
   
// send  
     email.send();   
   
   // sent success pop up   
   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SENT.fxml"));
   Parent root1 = (Parent) fxmlLoader.load();
   Stage stage = new Stage();
   stage.setTitle("Your Email Has been sent successfully !! ");
   Image ico = new Image("easymail/ico.png");
   stage.getIcons().add(ico);
   stage.setScene(new Scene(root1)); 
   stage.show();    
        
    }
    
    
    @FXML
    public void handleAbout(javafx.event.ActionEvent event) throws IOException {
   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ABOUT.fxml"));
   Parent root1 = (Parent) fxmlLoader.load();
   Stage stage = new Stage();
   stage.setTitle("People Behind");
   Image ico = new Image("easymail/ico.png");
   stage.getIcons().add(ico);
   stage.setScene(new Scene(root1)); 
   stage.show();
    }

    @FXML
    public void handleHowToUse(javafx.event.ActionEvent event) throws IOException {
   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HTU.fxml"));
   Parent root1 = (Parent) fxmlLoader.load();
   
   Stage stage = new Stage();
   stage.setTitle("How To Use");
   Image ico = new Image("easymail/ico.png");
   stage.getIcons().add(ico);
   
   stage.setScene(new Scene(root1));
   
   stage.show(); 
    }
    
    
    
    
    
     @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    
}
